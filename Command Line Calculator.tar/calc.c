#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

/*
 * The isinteger() function examines the string given as its first
 * argument, and returns true if and only if the string represents a
 * well-formed integer.  A well-formed integer consists only of an
 * optional leading - followed by one or more decimal digits.
 *
 * Returns true if the given string represents an integer, false
 * otherwise.
 */
bool isinteger(char *str);

/*
 * The parseint() function parses a well-formed string representation of
 * an integer (one which would return true from isinteger()) and returns
 * the integer value represented by the string.  For example, the string
 * "1234" would return the value 1234.  This function does not need to
 * handle badly-formed strings in any particular fashion, its operation
 * on badly-formed strings is undefined.
 *
 * Returns the integer value stored in the given string.
 */
int parseint(char *str);

/*
 * The main function is where C programs begin.
 *
 * This function parses its arguments and returns the value they
 * represent.  Its arguments are either:
 *
 *  - A single argument representing an integer
 *  - Three arguments, where the first and third are integers and the
 *    second is an operator to be performed on those integers
 *
 * Remember that the argument in argv[0] is the name of the program, so
 * a program passed exactly one argument on the command line will
 * receive _two_ arguments: its name in argv[0] and the provided
 * argument in argv[1].
 *
 * Arguments:
 * argc - The number of arguments received
 * argv - The arguments received as an array of C strings
 *
 * Returns 0 if the arguments are well-formed and the calculation could
 * be performed, non-zero otherwise.
 */
int main(int argc, char *argv[]) {
    if (argc == 2) {
        if (isinteger(argv[1]) == 1) {
            printf("%d\n", parseint(argv[1]));
            return 0;
        }
        else {
            printf("error\n");
            return 1;
        }
    }
    if (argc == 4) {
        if (isinteger(argv[1]) == 1 && isinteger(argv[3]) == 1) {
            if (argv[2][0] == '+') {
                printf("%d\n", (parseint(argv[1]) + parseint(argv[3])));
                return 0;
            }
            if (argv[2][0] == '-') {
                printf("%d\n", parseint(argv[1]) - parseint(argv[3]));
                return 0;
            }
            if (argv[2][0] == 'x') {
                printf("%d\n", parseint(argv[1]) * parseint(argv[3]));
                return 0;
            }
            if (argv[2][0] == '/' && argv[3][0] != '0') {
                printf("%d\n", parseint(argv[1]) / parseint(argv[3]));
                return 0;
            }
            else {
                printf("error\n");
                return 1;
                }
        }
        else {
            printf("error\n");
            return 1;
        }
    }
    else {
        printf("error\n");
        return 1;
    }
}

/* You should implement isinteger() and parseint() here */
bool isinteger(char *str) {
    int i;
    bool ool;

    for (i = 0; str[i] != '\0'; i++) {
        if (isdigit(str[i]) != 0) {
            ool = true;
        }
        else if (str[i] == '-' && i == 0) {
            ool = true;
        }
        else {
            ool = false;
            break;
        }
    }
    return ool;
}


int strrlen(char *str);
int getplace(int x);

int strrlen(char *str) {
    int i, num;
    num = 0;

    for (i = 0; str[i] != '\0'; i++) {
        if (str[i] == '-') {
            num = num;
        }
        else {
            num = num + 1;
        }
    }
    return num;
}

int getplace(int x) {
    int j, k;
    k = 1;

    for (j = x; j > 1; j--) {
        k = k * 10;
    }
    return k;
}

int parseint(char *str) {
    int i, j, num, ifneg;
    num = 0;
    ifneg = 1;
    int len = strrlen(str);
    j = len;

    if (str[0] == '-') {
        for (i = 0; i <= len; i++) {
            if (str[i] == '-') {
                ifneg = ifneg * -1;
            }
            else {
                int actual = str[i] - '0';
                num = num + (actual * getplace(j));
                j--;
            }
        }
    }
    else {
        for (i = 0; i < len; i++) {
            if (str[i] == '-') {
                ifneg = ifneg * -1;
            }
            else {
                int actual = str[i] - '0';
                num = num + (actual * getplace(j));
                j--;
            }
        }
    }
    return num * ifneg;
}
